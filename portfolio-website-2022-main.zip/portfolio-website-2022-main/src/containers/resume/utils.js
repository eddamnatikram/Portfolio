export const data = {
    experience: [
      {
        title: "Consultant",
        subTitle: "Miami, FL",
        description:
          " User Experience, Visual Design",
      },
      {
        title: "Senior Consultant",
        subTitle: "London, UK",
        description:
          "Web development, Databases, Backend developement",
      },
      {
        title: "Project Manager",
        subTitle: "Bangalore, INDIA",
        description:
          "Creative Direction Project Management, Team Leading",
      },
    ],
    education: [
      {
        title: "Secondary",
        subTitle: "ABC School",
        description:
          "10th Grade",
      },
      {
        title: "Higher Secondary",
        subTitle: "ABC School of higher education",
        description:
          "12th Grade in Science",
      },
      {
        title: "B.Tech",
        subTitle: "XYZ institute of technology",
        description:
          "Bachelor of technology in computer science",
      },
    ],
  };